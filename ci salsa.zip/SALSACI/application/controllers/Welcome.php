<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Welcome extends CI_Controller {

	public function index()
	{
		$this->load->view('welcome_message');
	}
	public function tambahdata()
	{
		$this->load->view('tambahdata');
	}
	public function tampildata()
	{
		$data['query']= $this->db->get('staff')->result_array();
		$this->load->view('tampildata', $data);
	}
	public function updatee($id)
	{
		$this->db->where('id',$id);
		$data['query']= $this->db->get('staff')->row_array();
		$this->load->view('updatedata', $data);
	}
	function insert(){
		$data = array(
			'id'=>$this->input->post('id'),
			'nama'=>$this->input->post('nama'),
			'umur'=>$this->input->post('umur'),
		);
		$this->db->insert('staff', $data);
		redirect('welcome/tampildata');
	}
	function update($id){
		$data = array(
			'id'=>$this->input->post('id'),
			'nama'=>$this->input->post('nama'),
			'umur'=>$this->input->post('umur')
		);
		$this->db->where('id',$id);
		$this->db->update('staff', $data);
		redirect('welcome/tampildata');
	}
	function delete($id){
		$this->db->where('id', $id);
		$this->db->delete('staff');
		redirect('welcome/tampildata');
	}
}